-- Do not delete "dictionary" and "foulwords" file.

-- This application used Logistic Regression Model for training data set.